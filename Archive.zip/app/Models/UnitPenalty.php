<?php

namespace App\Models;

use Ramsey\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;

class UnitPenalty extends Model
{
    protected $guarded = ['id'];

}
