<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KindDisruption extends Model
{
    protected $guarded = ['id'];

}
