@extends('layouts.app')


@section('content')
<div x-data="{sidebar:true}" class="w-screen overflow-hidden flex bg-[#E9ECEF]">
    @include('components.sidebar')
    <div class="max-h-screen overflow-hidden" :class="sidebar?'w-10/12' : 'w-full'">
        @include('components.header')
        <div class="w-full py-20 px-8 max-h-screen hide-scrollbar overflow-y-auto">
            <div class="flex items-end justify-between mb-2">
                <div>
                    <div class="text-[#135F9C] text-[40px] font-bold">
                        Tambah Dermaga
                    </div>
                    <div class="mb-4 text-[16px] text-[#6C757D] font-normal no-select">
                        <a href="{{ route('administration.dashboard') }}">Home</a> / <a href="{{ route('master-data.docks.index') }}" class="cursor-pointer">Dermaga</a>  / <span class="text-[#2E46BA] cursor-pointer">Create</span>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg p-6">
                <form onsubmit="return confirmSubmit(this, 'Tambahkan Dermaga?')" action="{{ route('master-data.docks.store') }}" method="POST">
                    @csrf
                    <div class="p-4 bg-white rounded-lg w-full">
                        <div class="lg:flex items-center justify-between">
                            <div class="w-full">
                                <label for="name" class="font-bold text-[#232D42] text-[16px]">Nama Dermaga</label>
                                <div class="relative">
                                    <input type="text" name="name" value="{{ old('name') }}" class="w-full lg:w-[300px] border rounded-md mt-3 mb-5 h-[40px] px-3">
                                    @error('name')
                                    <div class="absolute -bottom-1 left-1 text-red-500">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="w-full">
                                <label for="length" class="font-bold text-[#232D42] text-[16px]">Length</label>
                                <div class="relative">
                                    <input type="text" name="length" value="{{ old('length') }}" class="w-full lg:w-[300px] border rounded-md mt-3 mb-5 h-[40px] px-3">
                                    @error('length')
                                    <div class="absolute -bottom-1 left-1 text-red-500">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="lg:flex items-center justify-between">
                            <div class="w-full">
                                <label for="width" class="font-bold text-[#232D42] text-[16px]">Width</label>
                                <div class="relative">
                                    <input type="text" name="width" value="{{ old('width') }}" class="w-full lg:w-[300px] border rounded-md mt-3 mb-5 h-[40px] px-3">
                                    @error('width')
                                    <div class="absolute -bottom-1 left-1 text-red-500">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="w-full">
                                <label for="draft" class="font-bold text-[#232D42] text-[16px]">Draft</label>
                                <div class="relative">
                                    <input type="text" name="draft" value="{{ old('draft') }}" class="w-full lg:w-[300px] border rounded-md mt-3 mb-5 h-[40px] px-3">
                                    @error('draft')
                                    <div class="absolute -bottom-1 left-1 text-red-500">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="lg:flex items-center justify-between">
                            <div class="w-full">
                                <label for="load_rate" class="font-bold text-[#232D42] text-[16px]">Load Rate</label>
                                <div class="relative">
                                    <input type="text" name="load_rate" value="{{ old('load_rate') }}" class="w-full lg:w-[300px] border rounded-md mt-3 mb-5 h-[40px] px-3">
                                    @error('load_rate')
                                    <div class="absolute -bottom-1 left-1 text-red-500">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="mb-10">
                            <div class="w-full">
                                <label for="dock_equipment_lists" class="font-bold text-[#232D42] text-[16px]">Parameter pengecekan :</label>
                                <div class="relative mt-3">
                                    @foreach ($dock_equipment_lists as $list)
                                        <input type="checkbox" id="{{ $list->uuid }}" name="dock_equipment_lists[]" value="{{ $list->uuid }}">
                                        <label for="{{ $list->uuid }}"> {{ $list->name }}</label><br>
                                    @endforeach
                                    @error('dock_equipment_lists')
                                        <div class="absolute -bottom-1 left-1 text-red-500">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="mb-10">
                            <div class="w-full">
                                <label for="dock_inspection_lists" class="font-bold text-[#232D42] text-[16px]">Peralatan dermaga :</label>
                                <div class="relative mt-3">
                                    @foreach ($dock_inspection_lists as $list)
                                        <input type="checkbox" id="{{ $list->uuid }}" name="dock_inspection_lists[]" value="{{ $list->uuid }}">
                                        <label for="{{ $list->uuid }}"> {{ $list->name }}</label><br>
                                    @endforeach
                                    @error('dock_inspection_lists')
                                        <div class="absolute -bottom-1 left-1 text-red-500">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('master-data.docks.index') }}" class="bg-[#C03221] w-full lg:w-[300px] py-3 text-[white] text-[16px] font-semibold rounded-lg mt-3 px-3">Back</a>
                        <button class="bg-[#2E46BA] w-full lg:w-[300px] py-3 text-[white] text-[16px] font-semibold rounded-lg mt-3">Tambah Dermaga</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
